This zip archive contains four files:
female.wav
male.wav
music.wav
readme.txt (this file)

The sound file "female.wav" is adapted from the file "as0004.wav" contained in the archive found at URL
"http://www.repository.voxforge1.org/downloads/SpeechCorpus/Trunk/Audio/Original/44.1kHz_16bit/calamity-20071011-poe.tgz". The recording is in the public domain.

The sound file "male.wav" is adapted from the file "as0004.wav" contained in the archive found at URL
"http://www.repository.voxforge1.org/downloads/SpeechCorpus/Trunk/Audio/Original/44.1kHz_16bit/ttm-20071009-poe.tgz". The recording is in the public domain.

The sound file "music.wav" is adapted from the file "Guitare_bend.ogg" at URL "http://upload.wikimedia.org/wikipedia/commons/4/47/Guitare_bend.ogg". The file is licensed under the Creative Commons Attribution ShareAlike 2.5 License, as specified at URL "http://commons.wikimedia.org/wiki/Image:Guitare_bend.ogg".
